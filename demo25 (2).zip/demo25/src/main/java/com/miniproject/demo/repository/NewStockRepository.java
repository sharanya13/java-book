package com.miniproject.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.miniproject.demo.entity.NewStock;
public interface NewStockRepository extends JpaRepository<NewStock,Integer>
{
	
}