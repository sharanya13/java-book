package com.miniproject.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import jakarta.persistence.Column;

@Entity
@Table(name="OrderItems")
public class OrderItems
{
    @Id
    @Column(name="orderitemid")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int orderitemid ;
    
    @ManyToOne()
    @JoinColumn(name="orderid")
    private Orders orderid ;
    
    @ManyToOne()
    @JoinColumn(name="bookid")
    private Books bookid;
    
    @Column(name="bookprice")
    private double  bookprice;
    
    @Column(name="quantity")
    private int quantity;
    
    @Column(name="createdat")
    private LocalDateTime  createdat;
    
    public OrderItems() {}
	
	public OrderItems(int orderitemid, Orders orderid, Books bookid, double bookprice, int quantity,
			LocalDateTime createdat) {
		this.orderitemid = orderitemid;
		this.orderid = orderid;
		this.bookid = bookid;
		this.bookprice = bookprice;
		this.quantity = quantity;
		this.createdat = createdat;
	}
	
	public Books getBookid() {
		return bookid;
	}

	public void setBookid(Books bookid) {
		this.bookid = bookid;
	}

	public int getOrderitemid() {
		return orderitemid;
	}

	public void setOrderitemid(int orderitemid) {
		this.orderitemid = orderitemid;
	}

	public Orders getOrderid() {
		return orderid;
	}


	public void setOrderid(Orders orderid) {
		this.orderid = orderid;
	}

	public double getBookprice() {
		return bookprice;
	}

	public void setBookprice(double bookprice) {
		this.bookprice = bookprice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
    
}