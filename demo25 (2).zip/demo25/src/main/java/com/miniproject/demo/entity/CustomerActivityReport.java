package com.miniproject.demo.entity;
import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="customeractivityreport")
public class CustomerActivityReport 
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    
	@Column(name="customerid")
    private int customerid;
	
    @Column(name="bookspurchased")
    private int bookspurchased;
    
    @Column(name="totalprice")
    private double totalprice;
    
    @Column(name="orderdate")
    private LocalDate orderdate;

    @Column(name="createdat")
    private LocalDateTime createdat;

    public CustomerActivityReport() {}
    
	public CustomerActivityReport(int id, int customerid, int bookspurchased, double totalprice, LocalDate orderdate, LocalDateTime createdat) {
		this.id = id;
		this.customerid = customerid;
		this.bookspurchased = bookspurchased;
		this.totalprice = totalprice;
		this.orderdate = orderdate;
		this.createdat = createdat;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public int getBookspurchased() {
		return bookspurchased;
	}

	public void setBookspurchased(int bookspurchased) {
		this.bookspurchased = bookspurchased;
	}

	public double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}

	public LocalDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(LocalDate orderdate) {
		this.orderdate = orderdate;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
    
    

}
