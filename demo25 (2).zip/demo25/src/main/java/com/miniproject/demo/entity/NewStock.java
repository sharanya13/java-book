package com.miniproject.demo.entity;

import java.util.Date;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Newstock")
public class NewStock
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="stockid")
    private int stockid;
    @Column(name="adminid")
    private int adminid;
    @Column(name="bookid")
    private int bookid;
    @Column(name="stock")
    private int stock;
    @Column(name="createdat")
    private LocalDateTime  createdat ;
    
    public NewStock() {};
    
	public NewStock(int stockid, int adminid, int bookid, int stock, LocalDateTime createdat) 
	{
		this.stockid = stockid;
		this.adminid = adminid;
		this.bookid = bookid;
		this.stock = stock;
		this.createdat = createdat;
	}

	public int getStockid() {
		return stockid;
	}

	public void setStockid(int stockid) {
		this.stockid = stockid;
	}

	public int getAdminid() {
		return adminid;
	}

	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
 
}

