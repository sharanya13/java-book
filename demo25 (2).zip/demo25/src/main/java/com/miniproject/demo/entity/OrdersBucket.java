package com.miniproject.demo.entity;


import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="ordersbucket")
public class OrdersBucket
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    
    @Column(name="customerid")
    private int customerid;
    
    @ManyToOne
    @JoinColumn(name = "bookid")
    private Books bookid;
    
    @Column(name="quantity")
    private int quantity;
     @Column(name="price")
    private double price;
    @Column(name="createdat")
    private LocalDateTime createdat;

    public OrdersBucket(){}

	
	public OrdersBucket(int id, int customerid, Books bookid, int quantity, double price, LocalDateTime createdat) {

		this.id = id;
		this.customerid = customerid;
		this.bookid = bookid;
		this.quantity = quantity;
		this.price = price;
		this.createdat = createdat;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	

	public Books getBookid() {
		return bookid;
	}



	public void setBookid(Books bookid) {
		this.bookid = bookid;
	}



	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
    
    
}

 