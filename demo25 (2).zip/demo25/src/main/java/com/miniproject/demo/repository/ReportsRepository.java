package com.miniproject.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.miniproject.demo.entity.Reports;
public interface ReportsRepository extends JpaRepository<Reports,Integer>
{

}