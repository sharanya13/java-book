package com.miniproject.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Customers;
import com.miniproject.demo.repository.CustomersRepository;

@Service
public class CustomersService
{
    @Autowired
    CustomersRepository customersRepository;

    @Transactional(readOnly=true)
    public Optional<Customers> getCustomersById(int customerid)
    {
    	return customersRepository.findById(customerid);
    }
    
    @Transactional
	public List<Customers> validateCustomers(Customers customers)
	{
    	List<Customers> l = customersRepository.validateCustomers(customers.getUsername(),customers.getPassword());
    	return l;
	}
    
    @Transactional
	public int validateExistingCustomers(Customers customers)
	{
    	List<Customers> l = customersRepository.validateExistingCustomer(customers.getUsername());
    	return l.size();
	}

}

 