package com.miniproject.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.miniproject.demo.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin,Integer>
{
	@Procedure ("validate")
	List<Admin> validate
	(
		@Param("username") String username,
		@Param("password") String password
	); 
	
	@Procedure ("InsertAdmin")
	void InsertAdmin
	(
		
		@Param("name") String name,
		@Param("storecode")int storecode,
		@Param("username") String username,
		@Param("password") String password
	);
	
	@Procedure ("validateExistingAdmin")
	List<Admin> validateExistingAdmin
	(
			@Param("username") String username	
	);
}