package com.miniproject.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.miniproject.demo.entity.OrdersBucket;

public interface OrdersBucketRepository extends JpaRepository<OrdersBucket,Integer>
{
	@Procedure("PlaceOrder")
	void insertOrdersBucket
	(
		@Param("book_id") int bookid,
		@Param("quantity") int quantity
	);
	
	@Procedure("UpdateOrdersBucket")
	void updateBucket
	(
		@Param("book_id") int bookid,
		@Param("quantity") int quantity
	);
	
	
	@Procedure("RemoveItem")
	void removeItem
	(
		@Param("book_id") int bookid
	);
}