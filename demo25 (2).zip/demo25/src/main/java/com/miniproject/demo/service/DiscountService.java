package com.miniproject.demo.service;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Discount;
import com.miniproject.demo.repository.DiscountRepository;

@Service
public class DiscountService
{
	@Autowired
	DiscountRepository discountRepository;
	
	@Transactional(readOnly=true)
	public List<Discount> getAllDiscount()
	{
		return discountRepository.findAll();
	}
	@Transactional(readOnly=true)
	public Discount getDiscountByDiscountId(int DiscountId)
	{
		Optional<Discount> ot = discountRepository.findById(DiscountId);
		if(!ot.isPresent())
			System.out.println("not found");
		return ot.get();
		// throw new ResourceNotFoundException();
	}
	@Transactional
	public void insertOrModifyDiscount(Discount discount)
	{
		if(discountRepository.save(discount)==null)
			System.out.println("not found");
		// throw new ResourceNotModifiedException();
	}
	@Transactional
	public boolean deleteDiscountByDiscountId(int discountId)
	{
		long count =discountRepository.count();
		discountRepository.deleteById(discountId);
		if(count <= discountRepository.count())
			System.out.println("not found");
		return true;
		// throw new ResourceNotFoundException();
	}
}

 