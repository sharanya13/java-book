package com.miniproject.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Customers;
import com.miniproject.demo.repository.CustomersRepository;
import com.miniproject.demo.service. CustomersService;
import com.miniproject.demo.service.SessionService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/customers")
@RestController
public class CustomersController
{
      @Autowired
      CustomersService customersService;
      
      @Autowired
  	  SessionService sessionService;
      
      @Autowired
      CustomersRepository customersRepository;
      
      @GetMapping(value="/{customerid}",produces="application/json")
      public Optional< Customers> getCustomersById(@PathVariable int customerid)
      {
            Optional<Customers> clist =  customersService.getCustomersById(customerid);
            return clist;
      }
      
      
      //Login
      @PostMapping(value="/",consumes="application/json")
      public int validateCustomers(@RequestBody Customers customers)
      {
    	  List<Customers> l = customersService.validateCustomers(customers);
    	  
    	  if(l.size()!=0)
          {
	    	  for(int i=0;i<l.size();i++)
	    	  {
	    		  Customers c = l.get(i);
	    		  int id = c.getCustomerid();
	    		  sessionService.InsertIntoSession(id);
	    	  }
        	  return 1;
          }
          return 0;
      }
      
      //Registration
      @PostMapping(value="/insert",consumes="application/json")
      public int insertCustomers(@RequestBody Customers customers)
      {
    	  
    	if(customersService.validateExistingCustomers(customers)==0)
  		{
  			System.out.println("not existing");
  			customersRepository.insertCustomers(customers.getUsername(),customers.getPassword(),
            		  customers.getFirstname(),customers.getLastname(),customers.getEmail(),customers.getPhonenumber(),customers.getAddress(),customers.getPincode());
  			return 1;
  		}
  		return 0;
      }
}