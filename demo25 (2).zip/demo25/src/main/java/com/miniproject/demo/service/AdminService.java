package com.miniproject.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Admin;
import com.miniproject.demo.repository.AdminRepository;
 
@Service
public class AdminService
{
    @Autowired
    AdminRepository adminRepository;

    @Transactional(readOnly=true)
    public List<Admin> getAllAdmin()
    {
    	return adminRepository.findAll();
    }
    
    @Transactional
    public void InsertAdmin(Admin admin)
    {
    	adminRepository.InsertAdmin(admin.getName(),admin.getStorecode(),admin.getUsername(),admin.getPassword());
    }
    
    @Transactional
    public int validateExistingAdmin(Admin admin)
    {
    	List<Admin> l = adminRepository.validateExistingAdmin(admin.getUsername());
    	return l.size();
    }
}