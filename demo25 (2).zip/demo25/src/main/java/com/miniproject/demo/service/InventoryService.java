package com.miniproject.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Inventory;
import com.miniproject.demo.repository.InventoryRepository;

@Service
public class InventoryService
{
	@Autowired
	InventoryRepository inventoryRepository;
	
	@Transactional(readOnly=true)
	public List<Inventory> getAllInventory()
	{
		return inventoryRepository.findAll();
	}
    @Transactional(readOnly=true)
    public Inventory getInventoryByInventoryId(int inventoryId)
    {
    	Optional<Inventory> ot = inventoryRepository.findById(inventoryId);
	    if(!ot.isPresent())
	    	System.out.println("not found");
        return ot.get();
        // throw new ResourceNotFoundException();
    }
	@Transactional
	public void insertOrModifyInventory(Inventory inventory)
	{
		if(inventoryRepository.save(inventory)==null)
			System.out.println("not found");
		// throw new ResourceNotModifiedException();
	}
	
	@Transactional
	public boolean deleteInventoryByInventoryId(int inventoryId)
	{
		long count =inventoryRepository.count();
		inventoryRepository.deleteById(inventoryId);
		if(count <= inventoryRepository.count())
			System.out.println("not found");
		return true;
		// throw new ResourceNotFoundException();
	}
}