package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Reports")
public class Reports
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="reportid")
    private int  reportid;
    @Column(name="bookid")
    private int bookid;
    @Column(name="title")
    private String title;
    @Column(name="stocklevelused")
    private int stocklevelused;
    @Column(name="createdat")
    private LocalDateTime createdat ;

    public Reports(){}

	public Reports(int reportid, int bookid, String title, int stocklevelused, LocalDateTime createdat) {
		this.reportid = reportid;
		this.bookid = bookid;
		this.title = title;
		this.stocklevelused = stocklevelused;
		this.createdat = createdat;
	}

	public int getReportid() {
		return reportid;
	}

	public void setReportid(int reportid) {
		this.reportid = reportid;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getStocklevelused() {
		return stocklevelused;
	}

	public void setStocklevelused(int stocklevelused) {
		this.stocklevelused = stocklevelused;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
     
}

 