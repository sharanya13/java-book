package com.miniproject.demo.service;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.Reports;
import com.miniproject.demo.repository.ReportsRepository;
@Service
public class ReportsService
{
	@Autowired
	ReportsRepository reportsRepository;
	@Transactional(readOnly=true)
	public List<Reports> getAllReports()
	{
		return reportsRepository.findAll();
    }
	
    @Transactional(readOnly=true)
    public Reports getReportsByReportsId(int reportsId)
    {
    	Optional<Reports> ot = reportsRepository.findById(reportsId);
    	if(!ot.isPresent())
    		System.out.println("not found");
        return ot.get();
        // throw new ResourceNotFoundException();
    }

	@Transactional
	public void insertOrModifyReports (Reports reports)
	{
		if(reportsRepository.save(reports)==null)
			System.out.println("not found");
		// throw new ResourceNotModifiedException();
	}
	
	@Transactional
	public boolean deleteReportsByReportsId(int reportsId)
	{
		long count =reportsRepository.count();
		reportsRepository.deleteById(reportsId);
		if(count <= reportsRepository.count())
			System.out.println("not found");
		return true;
		// throw new ResourceNotFoundException();
	}
}