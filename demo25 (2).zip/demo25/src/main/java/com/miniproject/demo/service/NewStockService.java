package com.miniproject.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.NewStock;
import com.miniproject.demo.repository.NewStockRepository;

@Service
public class NewStockService
{
	@Autowired
	NewStockRepository newStockRepository; 
	
	@Transactional(readOnly=true)
	public List<NewStock> getAllNewStock()
	{
		return newStockRepository.findAll();
	}
	
	@Transactional(readOnly=true)
	public NewStock getNewStockByNewStockId(int newStockId)
	{
		Optional<NewStock> ot = newStockRepository.findById(newStockId);
		if(!ot.isPresent())
			System.out.println("not found");
		return ot.get();
		// throw new ResourceNotFoundException();
	}
	
	@Transactional
	public void insertOrModifyNewStock(NewStock newStock)
	{
		if(newStockRepository.save(newStock)==null)
			System.out.println("not found"); 
		// throw new ResourceNotModifiedException();
	}
	        
	@Transactional
	public boolean deleteNewStockByNewStockId(int newStockId)
	{
		long count =newStockRepository.count();
		newStockRepository.deleteById(newStockId);
		if(count <= newStockRepository.count())
			System.out.println("not found");
		return true;
	}
}