package com.miniproject.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Inventory;
import com.miniproject.demo.service.InventoryService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/inventory")
@RestController
public class InventoryController
{
      @Autowired
      InventoryService inventoryService;
      @GetMapping(value="/",produces="application/json")
      public ResponseEntity<List< Inventory>> getAllInventory()
      {
            List< Inventory> ilist =  inventoryService.getAllInventory();
            if(ilist.size()!=0)
                return new ResponseEntity<List<Inventory>>(ilist,HttpStatus.OK);
            return new ResponseEntity<List<Inventory>>(ilist,HttpStatus.NOT_FOUND);
       }
      @GetMapping(value="/{inventoryId}",produces="application/json")
      public ResponseEntity< Inventory> getInventoryByInventoryId(@PathVariable int inventoryId)
      {
          Inventory i = inventoryService.getInventoryByInventoryId(inventoryId);
            if(i!=null)
                return new ResponseEntity<Inventory>(i,HttpStatus.OK);
            return new ResponseEntity<Inventory>(i,HttpStatus.NOT_FOUND);
      }
      @PostMapping(value="/",consumes="application/json")
      public HttpStatus insertInventory(@RequestBody Inventory inventory)
      {
          inventoryService.insertOrModifyInventory(inventory);
              return HttpStatus.OK;
      }
      @PutMapping(consumes="application/json")
      public HttpStatus modifyInventory(@RequestBody Inventory inventoryId)
      {
          inventoryService.insertOrModifyInventory(inventoryId);
              return HttpStatus.OK;
      }
      @DeleteMapping("/{inventoryId}")
      public HttpStatus deleteInventory(@PathVariable int InventoryId)
      {
          if(inventoryService.deleteInventoryByInventoryId(InventoryId))
              return HttpStatus.OK;
          return HttpStatus.NOT_FOUND;
      }
}