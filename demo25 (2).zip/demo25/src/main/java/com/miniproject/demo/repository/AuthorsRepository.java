package com.miniproject.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miniproject.demo.entity.Authors;

 

public interface AuthorsRepository extends JpaRepository<Authors,Integer>
{
 

}