package com.miniproject.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.miniproject.demo.entity.Orders;
public interface OrdersRepository extends JpaRepository<Orders,Integer>
{

 

}