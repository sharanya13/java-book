package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Authors
{
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   @Column(name="authorid")
   private int authorid;
   
   @Column(name="authorname")
   private String authorname;
   
   @Column(name="country")
   private String country;
   
   @Column(name="email")
   private String email;
   
   @Column(name="phonenumber")
   private long phonenumber;
   
   @Column(name="createdat")
   private LocalDateTime createdat;
   
   public Authors() {}
   
	public Authors(int authorid, String authorname, String country, String email, long phonenumber, LocalDateTime createdat) {
		this.authorid = authorid;
		this.authorname = authorname;
		this.country = country;
		this.email = email;
		this.phonenumber = phonenumber;
		this.createdat = createdat;
	}
	public int getAuthorid() {
		return authorid;
	}
	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}
	public String getAuthorname() {
		return authorname;
	}
	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}
	public LocalDateTime getCreatedat() {
		return createdat;
	}
	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
}

 