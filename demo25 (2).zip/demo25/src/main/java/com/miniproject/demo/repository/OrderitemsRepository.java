package com.miniproject.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;

import com.miniproject.demo.entity.OrderItems;

public interface OrderitemsRepository extends JpaRepository<OrderItems,Integer> 
{
	@Procedure("get_orders")
	List<OrderItems> getOrders();
}
