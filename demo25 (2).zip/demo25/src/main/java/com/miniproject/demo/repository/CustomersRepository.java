package com.miniproject.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.miniproject.demo.entity.Customers;

public interface CustomersRepository extends JpaRepository<Customers,Integer>
{

	@Procedure("InsertCustomer")
	void insertCustomers
	(	
		@Param("username") String username,
		@Param("password") String password,
		@Param("FirstName") String firstname,
		@Param("LastName") String lastname,
		@Param("Email") String email,
		@Param("PhoneNumber") long phonenumber,
		@Param("address") String address,
		@Param("PinCode") int pincode
	);
	
	@Procedure("validateExistingCustomer")
	List<Customers> validateExistingCustomer(
	    @Param("username") String username
	);
	
	@Procedure("validateCustomer")
	List<Customers> validateCustomers(
	    @Param("username") String username,
	    @Param("password") String password
	);

}