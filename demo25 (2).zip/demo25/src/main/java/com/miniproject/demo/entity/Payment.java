package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="Payment")
public class Payment
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="paymentid")
    private int  paymentid;
    @Column(name="customerid")
    private int  customerid;
    @Column(name="totalamount")
    private double totalamount;
    @Column(name="status")
    private String status;
    @Column(name="shipping")
    private double shipping;
    @Column(name="tax")
    private double  tax;
    @Column(name="createdat")
    private LocalDateTime  createdat ;

    public Payment(){}

	public Payment(int paymentid, int customerid, double totalamount, String status, double shipping, double tax,
			LocalDateTime createdat) {
		this.paymentid = paymentid;
		this.customerid = customerid;
		this.totalamount = totalamount;
		this.status = status;
		this.shipping = shipping;
		this.tax = tax;
		this.createdat = createdat;
	}

	public double getShipping() {
		return shipping;
	}

	public void setShipping(double shipping) {
		this.shipping = shipping;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public int getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(int paymentid) {
		this.paymentid = paymentid;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public double getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
    
}