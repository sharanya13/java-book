package com.miniproject.demo.entity;

import java.util.Date;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Orders")
public class Orders
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="orderid")
    private int orderid;
    @Column(name="customerid")
    private int customerid;
    
    @OneToOne()
    @JoinColumn(name="paymentid")
    private Payment paymentid ;
    @Column(name="ordereddate")
    private Date  ordereddate ;
    @Column(name="arrivaldate")
    private Date  arrivaldate ;
    @Column(name="createdat")
    private LocalDateTime createdat ;
    public Orders() {}
    
	public Orders(int orderid, int customerid, Payment paymentid, Date ordereddate, Date arrivaldate,
			LocalDateTime createdat) {
		this.orderid = orderid;
		this.customerid = customerid;
		this.paymentid = paymentid;
		this.ordereddate = ordereddate;
		this.arrivaldate = arrivaldate;
		this.createdat = createdat;
	}


	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	
	public Payment getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(Payment paymentid) {
		this.paymentid = paymentid;
	}

	public Date getOrdereddate() {
		return ordereddate;
	}
	public void setOrdereddate(Date ordereddate) {
		this.ordereddate = ordereddate;
	}
	public Date getArrivaldate() {
		return arrivaldate;
	}
	public void setArrivaldate(Date arrivaldate) {
		this.arrivaldate = arrivaldate;
	}
	public LocalDateTime getCreatedat() {
		return createdat;
	}
	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
}