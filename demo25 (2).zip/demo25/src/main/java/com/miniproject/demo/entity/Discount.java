package com.miniproject.demo.entity;

import java.util.Date;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Discount")
public class Discount
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="discountid")
    private int  discountid;
    
    @Column(name="bookid")
    private int  bookid;
    
    @Column(name="discountamount")
    private int  discountamount;
    
    @Column(name="createdat")
    private LocalDateTime  createdat ;

    public Discount(){}

	public Discount(int discountid, int bookid, int discountamount, LocalDateTime createdat)
	{
		this.discountid = discountid;
		this.bookid = bookid;
		this.discountamount = discountamount;
		this.createdat = createdat;
	}

	public int getDiscountid() {
		return discountid;
	}

	public void setDiscountid(int discountid) {
		this.discountid = discountid;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public int getDiscountamount() {
		return discountamount;
	}

	public void setDiscountamount(int discountamount) {
		this.discountamount = discountamount;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
    
    
}

 