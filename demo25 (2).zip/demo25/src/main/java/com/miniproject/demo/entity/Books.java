package com.miniproject.demo.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Books")
public class Books
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="bookid")
    private int bookid;
    
    @Column(name="urls")
    private String urls;
    
    @ManyToOne
    @JoinColumn(name = "authorid")
    private Authors authorid;
   
    @Column(name="title")
    private String title;

    @Column(name="isbn")
    private long isbn;
 
    @Column(name="category")
    private String category;

    @Column(name="publicationyear")
    private LocalDate publicationyear;
 
    @Column(name="price")
    private double price;
    
    @Column(name="discount")
    private int discount ;
    
    @Column(name="createdat")
    private LocalDateTime createdat;

    public Books() {}

	public Books(int bookid, String urls, Authors authorid, String title, long isbn, String category,
			LocalDate publicationyear, double price, int discount, LocalDateTime createdat) {
		super();
		this.bookid = bookid;
		this.urls = urls;
		this.authorid = authorid;
		this.title = title;
		this.isbn = isbn;
		this.category = category;
		this.publicationyear = publicationyear;
		this.price = price;
		this.discount = discount;
		this.createdat = createdat;
	}

	public int getDiscount() {
		return discount;  
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public int getBookid() {
		return bookid;
	}


	public void setBookid(int bookid) {
		this.bookid = bookid;
	}


	public Authors getAuthorid() {
		return authorid;
	}


	public void setAuthorid(Authors authorid) {
		this.authorid = authorid;
	}
	

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getIsbn() {
		return isbn;
	}

	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public LocalDate getPublicationyear() {
		return publicationyear;
	}

	public void setPublicationyear(LocalDate publicationyear) {
		this.publicationyear = publicationyear;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}

	public String getUrls() {
		return urls;
	}

	public void setUrls(String urls) {
		this.urls = urls;
	}
    
}