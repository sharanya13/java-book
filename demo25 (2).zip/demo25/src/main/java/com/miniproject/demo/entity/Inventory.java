package com.miniproject.demo.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Inventory")
public class Inventory
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="inventoryid")
    private int inventoryid;
    @Column(name="bookid")
    private int    bookid;
    @Column(name="stocklevelused")
    private int stocklevelused;
    @Column(name="stocklevelleft")
    private int stocklevelleft;
    @Column(name="createdat")
    private LocalDateTime createdat ;
	public Inventory(int inventoryid, int bookid, int stocklevelused, int stocklevelleft, LocalDateTime createdat) 
	{
		this.inventoryid = inventoryid;
		this.bookid = bookid;
		this.stocklevelused = stocklevelused;
		this.stocklevelleft = stocklevelleft;
		this.createdat = createdat;
	}
	public int getInventoryid() {
		return inventoryid;
	}
	public void setInventoryid(int inventoryid) {
		this.inventoryid = inventoryid;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public int getStocklevelused() {
		return stocklevelused;
	}
	public void setStocklevelused(int stocklevelused) {
		this.stocklevelused = stocklevelused;
	}
	public int getStocklevelleft() {
		return stocklevelleft;
	}
	public void setStocklevelleft(int stocklevelleft) {
		this.stocklevelleft = stocklevelleft;
	}
	public LocalDateTime getCreatedat() {
		return createdat;
	}
	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}
}