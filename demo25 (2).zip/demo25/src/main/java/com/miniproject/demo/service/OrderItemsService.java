package com.miniproject.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.miniproject.demo.entity.OrderItems;
import com.miniproject.demo.repository.OrderitemsRepository;
@Service
public class OrderItemsService
{
    @Autowired
    OrderitemsRepository orderItemsRepository;
    
    @Transactional(readOnly=true)
    public List<OrderItems> getAllOrderItems()
    {
    	return orderItemsRepository.getOrders();
    }
}
