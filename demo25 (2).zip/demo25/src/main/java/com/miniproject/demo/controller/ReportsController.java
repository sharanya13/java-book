package com.miniproject.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Reports;
import com.miniproject.demo.service.ReportsService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/reports")
@RestController
public class ReportsController
{
	  @Autowired
      ReportsService reportsService;
      @GetMapping(value="/",produces="application/json")
      public ResponseEntity<List<Reports>> getAllReports()
      {
            List<Reports> rlist =  reportsService.getAllReports();
            if(rlist.size()!=0)
                return new ResponseEntity<List<Reports>>(rlist,HttpStatus.OK);
            return new ResponseEntity<List<Reports>>(rlist,HttpStatus.NOT_FOUND);
       }
      
      @GetMapping(value="/{reportsId}",produces="application/json")
      public ResponseEntity<Reports> getReportsByReportsId(@PathVariable int reportsId)
      {
    	  Reports r = reportsService.getReportsByReportsId(reportsId);
            if(r!=null)
                return new ResponseEntity<Reports>(r,HttpStatus.OK);
            return new ResponseEntity<Reports>(r,HttpStatus.NOT_FOUND);
      }
      
      @PostMapping(value="/",consumes="application/json")
      public HttpStatus insertReports(@RequestBody Reports reports)
      {
    	  reportsService.insertOrModifyReports(reports);
              return HttpStatus.OK;
      }
      
      @PutMapping(consumes="application/json")
      public HttpStatus modifyReports(@RequestBody Reports reportsId)
      {
    	 reportsService.insertOrModifyReports(reportsId);
              return HttpStatus.OK;
      }
      
      @DeleteMapping("/{ReportsId}")
      public HttpStatus deleteReports(@PathVariable int ReportsId)
      {
          if(reportsService.deleteReportsByReportsId(ReportsId))
              return HttpStatus.OK;
          return HttpStatus.NOT_FOUND;
      }
}

 