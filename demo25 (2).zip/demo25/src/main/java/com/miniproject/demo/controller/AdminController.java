package com.miniproject.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.miniproject.demo.entity.Admin;
import com.miniproject.demo.repository.AdminRepository;
import com.miniproject.demo.service.AdminService;

@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/admin")
@RestController
public class AdminController
{
	@Autowired
	AdminService adminService;
	
	@Autowired 
	AdminRepository adminRepository;
	
	@GetMapping(value="/",produces="application/json")
	public List<Admin> getAllAdmin()
	{
		List<Admin> alist =  adminService.getAllAdmin();
		return alist;
	}
	
	@Transactional
	@PostMapping(value="/",consumes="application/json")
	public int validateAdmin(@RequestBody Admin admin)
	{
		List<Admin> l = adminRepository.validate(admin.getUsername(),admin.getPassword());
		return l.size();
	}
	
	@Transactional
	@PostMapping(value="/insert",consumes="application/json")
	public int InsertAdmin(@RequestBody Admin admin)
	{
		if(admin.getStorecode()==162409 && adminService.validateExistingAdmin(admin)==0)
		{
			System.out.println("not existing");
			adminService.InsertAdmin(admin);
			return 1;
		}
		return 0;
	}
}